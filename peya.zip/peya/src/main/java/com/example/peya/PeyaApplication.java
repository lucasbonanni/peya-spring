package com.example.peya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeyaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeyaApplication.class, args);
	}

}
